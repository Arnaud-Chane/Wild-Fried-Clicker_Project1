# project1

Figma Laptop :
https://www.figma.com/file/9tGawBw10XSXSHjfASUS3k/Laptop?node-id=0%3A1&t=aAsMWEz3vSVWarSd-0


Figma Mobile :
https://www.figma.com/file/o2b0r3zEdu09fgrTU3Ra7o/Mobile-Draft?node-id=0%3A1&t=bfN03bp8tKgCQlth-0




